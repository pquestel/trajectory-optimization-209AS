function dz = dynamics3(z,u,p)

m = p.m;
I = p.I;
r = p.r;

%% State definition

xt = z(1,:);
yt = z(2,:);
xc = z(3,:);
yc = z(4,:);
q = z(5,:);

%% Input definition

vx = u(1,:);
vy = u(2,:);
w = u(3,:);

%% System Dynamics

dxc = vx;
dyc = vy;
dq = w;
dxt = dxc - w.*r.*sin(q);
dyt = dyc + w.*r.*cos(q);



dz = [dxt;dyt;dxc;dyc;dq];

end

