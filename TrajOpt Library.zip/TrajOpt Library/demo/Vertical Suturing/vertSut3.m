% Main - Vertical Suturing 


clc; clear;

addpath ../../

%% Physical parameters of the problem 

p.w = 0.005; % wound width in m
p.d = 0.004; % wound depth in m
p.m = 0.030; % needle weight in kg.
p.r = 0.0083; % needle radius in mm (for a half circle needle).
p.I = p.m/2 *p.r.^2; % to be verified
 
NN = 0.001; % NN depth in m
FF = 0.002; % FF depth in m

duration = 2;


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up function handles                             %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.func.dynamics = @(t,z,u)(dynamics3(z,u,p));
problem.func.pathObj = @(t,z,u)(u(1,:).^2 + u(2,:).^2); % cost function


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up problem bounds                               %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.bounds.initialTime.low = 0;
problem.bounds.initialTime.upp = 0;
problem.bounds.finalTime.low = duration;
problem.bounds.finalTime.upp = duration;


problem.bounds.state.low = [-0.010;-0.010;-0.010;-0.010;0];
problem.bounds.state.upp = [0.010;0.010;0.010;0.010;2*pi];


problem.bounds.initialState.low = [-0.006;0;0;0.0058;5*pi/4];
problem.bounds.initialState.upp = [-0.006;0;0;0.0058;5*pi/4];


problem.bounds.finalState.low = [0;0.0025;-inf;-inf;3*pi/2];
problem.bounds.finalState.upp = [0;0.0025;inf;inf;3*pi/2];


problem.bounds.control.low = [-0.001;-0.001;-pi/18];
problem.bounds.control.upp = [0.001;0.001;pi/18];

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                    Initial guess at trajectory                          %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.guess.time = [0,duration];
problem.guess.state = [problem.bounds.initialState.low, problem.bounds.finalState.low];
problem.guess.control = [0,0;0,0;0,0];

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                         Solver options                                  %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.options.nlpOpt = optimset(...
    'Display','iter',...
    'MaxFunEvals',1e5);

problem.options.method = 'trapezoid';
problem.options.defaultAccuracy = 'medium';

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                            Solve!                                       %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

soln = optimTraj(problem);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                        Display Solution                                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

%%%% Unpack the simulation
t = linspace(soln.grid.time(1), soln.grid.time(end), 150);
z = soln.interp.state(t);
u = soln.interp.control(t);

xt = z(1,:);
yt = z(2,:);
xc = z(3,:);
yc = z(4,:);
q = z(5,:);

vx = u(1,:);
vy = u(2,:);
w = u(3,:);

%plot the solution:

figure(1); clf;
subplot(3,1,1);
plot(t,xt)
ylabel('xt')
title('Optimal Vertical suturing');

subplot(3,1,2)
plot(t,yt);
ylabel('yt');

subplot(3,1,3)
plot(t,q)
ylabel('q')

figure(2);
subplot(3,1,1);
plot(t,vx);
ylabel('vx');

figure(2);
subplot(3,1,1);
plot(t,vy);
ylabel('vy');

subplot(3,1,3);
plot(t,w);
ylabel('w');

