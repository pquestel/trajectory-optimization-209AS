% Main - Vertical Suturing 


clc; clear;

addpath ../../

%% Physical parameters of the problem 

p.w = 0.005; % wound width in m
p.d = 0.004; % wound depth in m
p.m = 0.030; % needle weight in kg.
p.r = 0.0083; % needle radius in mm (for a half circle needle).
p.I = p.m/2 *p.r^2; % to be verified
 
NN = 0.001; % NN depth in m
FF = 0.002; % FF depth in m

duration = 2;

xFinalSolution = [];
yFinalSolution = [];
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up function handles                             %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.func.dynamics = @(t,z,u)(dynamics2(z,u,p));
% problem.func.pathObj = @(t,z,u)(u(1,:).^2 + u(2,:).^2); % cost function
problem.func.pathObj = @(t,z,u)(z(1,:).^2 + z(2,:).^2);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up problem bounds                               %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.bounds.initialTime.low = 0;
problem.bounds.initialTime.upp = 0;
problem.bounds.finalTime.low = duration;
problem.bounds.finalTime.upp = duration;

problem.bounds.state.low = [-0.010;-0.010;0;-0.0010;-0.0010;-pi/6]; %State is x,y,q,dx,dy,dq
problem.bounds.state.upp = [0.010;0.010;2*pi;0.010;0.010;pi/6];

% problem.bounds.state.low = [-inf;-inf;pi;-inf;-inf;-inf];
% problem.bounds.state.upp = [0;0;3*pi/2;inf;inf;inf];

problem.bounds.initialState.low = [-(p.w/2)-0.008;0;pi;0;0;0]; %State is x,y,q,dx,dy,dq
problem.bounds.initialState.upp = [-(p.w/2)-0.004;0;5*pi/4;0;0;0];

% problem.bounds.initialState.low = [-0.007;0;pi;0;0;0]; %State is x,y,q,dx,dy,dq
% problem.bounds.initialState.upp = [-0.007;0;5*pi/4;0;0;0];


problem.bounds.finalState.low = [-0.00115;0.002;3*pi/2;0;0;0];   % we consider y as positive
problem.bounds.finalState.upp = [0.00115;0.004;3*pi/2;0;0;0];

% problem.bounds.finalState.low = [-0.00115;-0.004;8*pi/6;0;0;0];
% problem.bounds.finalState.upp = [0.00115;-0.002;10*pi/6;0;0;0];

% problem.bounds.control.low = [-0.1;-0.1;1];
% problem.bounds.control.upp = [0.1;0.1;10];

problem.bounds.control.low = [-inf;-inf;-inf];
problem.bounds.control.upp = [inf;inf;inf];


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                    Initial guess at trajectory                          %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.guess.time = [0,duration];
problem.guess.state = [problem.bounds.initialState.low, problem.bounds.finalState.low];
problem.guess.control = [0,0;0,0;0,0];

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                         Solver options                                  %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.options.nlpOpt = optimset(...
    'Display','iter',...
    'MaxFunEvals',1e7);

problem.options.method = 'trapezoid';
problem.options.defaultAccuracy = 'medium';

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                            Solve!                                       %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

soln = optimTraj(problem);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                        Display Solution                                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

%%%% Unpack the simulation
t = linspace(soln.grid.time(1), soln.grid.time(end), 150);
z = soln.interp.state(t);
u = soln.interp.control(t);

x = z(1,:);
y = -z(2,:);
q = z(3,:);
dx = z(4,:);
dy = z(5,:);
dq = z(6,:);

Fx = u(1,:);
Fy = u(2,:);
thau = u(3,:);


%plot the solution:

figure(1); clf;
subplot(3,1,1);
plot(t,x)
ylabel('x')
title('Optimal Vertical suturing');

subplot(3,1,2)
plot(t,y);
ylabel('y');

subplot(3,1,3)
plot(t,q)
ylabel('q')

figure(2);
subplot(3,1,1);
plot(t,Fx);
ylabel('Fx');

subplot(3,1,2);
plot(t,Fy);
ylabel('Fy');

subplot(3,1,3);
plot(t,thau);
ylabel('thau');

figure();
plot(x,y);

xFinalSolution = x;
yFinalSolution = y;


%% Second part of the trajectory 

problem.bounds.state.low = [-0.010;-0.010;0;-0.0010;-0.0010;-pi/6]; %State is x,y,q,dx,dy,dq
problem.bounds.state.upp = [0.010;0.010;2*pi;0.010;0.010;pi/6];

problem.bounds.initialState.low = [x(end);y(end);q(end);dx(end);dy(end);dq(end)]; %State is x,y,q,dx,dy,dq
problem.bounds.initialState.upp = [x(end);y(end);q(end);dx(end);dy(end);dq(end)];

problem.bounds.finalState.low = [p.w/2+0.004;0;3*pi/2;0;0;0];   % we consider y as positive
problem.bounds.finalState.upp = [p.w/2+0.008;0;2*pi;0;0;0];

problem.bounds.control.low = [-inf;-inf;-inf];
problem.bounds.control.upp = [inf;inf;inf];


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                    Initial guess at trajectory                          %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.guess.time = [0,duration];
problem.guess.state = [problem.bounds.initialState.low, problem.bounds.finalState.low];
problem.guess.control = [0,0;0,0;0,0];


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                         Solver options                                  %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.options.nlpOpt = optimset(...
    'Display','iter',...
    'MaxFunEvals',1e7);

problem.options.method = 'trapezoid';
problem.options.defaultAccuracy = 'medium';

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                            Solve!                                       %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

soln = optimTraj(problem);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                        Display Solution                                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

%%%% Unpack the simulation
t = linspace(soln.grid.time(1), soln.grid.time(end), 150);
z = soln.interp.state(t);
u = soln.interp.control(t);

x2 = z(1,:);
y2 = z(2,:);
q2 = z(3,:);
dx2 = z(4,:);
dy2 = z(5,:);
dq2 = z(6,:);

Fx2 = u(1,:);
Fy2 = u(2,:);
thau2 = u(3,:);

figure()
plot(x2,y2);

xFinalSolution = [xFinalSolution x2];
yFinalSolution = [yFinalSolution y2];

figure()
plot(xFinalSolution,yFinalSolution);

figure()
plot(t,x.^2 + y.^2)