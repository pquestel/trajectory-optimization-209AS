# README.md  --  Simple Walker

This example shows how to compute a periodic gait for a double pendulum model of walking.

Entry-point script is MAIN.m

Derive the dynamics using Derive_SimpleWalker.m
