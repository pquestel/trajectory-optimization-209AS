# README.md  --  Toy Car

 Dynamics:
   A simple model of a car, where the state is its position and
   orientation, and the control is the rate of change in steering. Similar to linear tangent steering.

 Objective:
   Find the best path between two points that avoids driving on steep
   slopes.

Entry-point script: MAIN.m


